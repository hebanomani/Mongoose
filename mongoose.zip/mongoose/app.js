var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var Book = require('./Book.model');

var db='mongodb://localhost/example';

mongoose.connect(db);

app.get('/',function(req,res){
  res.send('Hello I am here');
});

app.get('/books',function(req,res){
  console.log("All my books");
  Book.find({})
  .exec(function(err,books){
    if(err){
      res.send("Error has occured");
    }
    else{
      console.log(books);
      res.json(books);
    }
  });

});

app.listen(8080, function(){
   console.log('App listening on port' +8080);
});
